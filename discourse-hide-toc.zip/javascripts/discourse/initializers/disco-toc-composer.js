import { withPluginApi } from "discourse/lib/plugin-api";

export default {
  name: "hide-toc-composer",

  initialize() {
    withPluginApi("1.0.0", (api) => {
      const currentUser = api.getCurrentUser();
      if (!currentUser) {
        return;
      }

      // 直接添加工具栏选项
      api.addComposerToolbarPopupMenuOption({
        action: (toolbarEvent) => {
          toolbarEvent.applySurround(
            `<div data-theme-toc="false">`,
            `</div>`,
            "contains_dtoc"
          );
        },
        icon: "align-left",
        label: "移除目录",
        condition: (composer) => {
          return composer.model.topicFirstPost;
        },
      });
    });
  },
};
